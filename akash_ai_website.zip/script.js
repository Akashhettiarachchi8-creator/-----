function downloadApp(){
  alert("APK download coming soon!");
}
